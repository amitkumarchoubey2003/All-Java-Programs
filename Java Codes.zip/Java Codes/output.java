class output 
    {
         public static void main(String args[]) 
         {
             double x = 3.14;  
             int y = (int) Math.ceil(x);
             System.out.print(y);
         }
    }
