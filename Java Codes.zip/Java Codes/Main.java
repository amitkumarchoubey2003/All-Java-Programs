class Main 
{ 
public static void main(String[] args) 
  {  
   String first = "Java"; 
   String second = "Python"; 
   String third = "JavaScript";  
   System.out.println(first);
   System.out.println(second); 
    System.out.println(third);  
   } 

}