import java.util.Scanner;

public class SquareArea {
 public static void main(String[] args) {
 int side = 5;
 int area = side*side;
 System.out.println("Area of Suare:" +area);
}
}

















 