import java.util.Scanner;

public class CircleCircumference {
 public static void main(String[] args) {
 double radius = 9.5; 
 double circumference = 2*Math.PI*radius;
 System.out.println("Circumference of circle:" +circumference);

}
}
