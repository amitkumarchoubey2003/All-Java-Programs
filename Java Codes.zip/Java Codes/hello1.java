public class hello1   {  
           public static void main (String args[]) 
{  
        System.out.println(100 + 100 +“BCA SEM 5");   
        System.out.println(“BCA SEM 5" + 100 + 100);    }  
}
