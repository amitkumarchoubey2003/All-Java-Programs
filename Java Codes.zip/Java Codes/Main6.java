class Main6 
{ 
public static void main(String[] args) 
{  
String example = "Hello! ";
System.out.println(example);
example = example.concat(" World");
System.out.println(example); 
} 
}