class PrintMessage 
{ 
public static void main(String[] args) 
{  
//String example = "This is the "String" class"; 
//System.out.println(example); 
String example = "This is the \"String\" class.";
System.out.println(example);
} 
}