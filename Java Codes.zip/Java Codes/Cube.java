import java.util.Scanner;

public class Cube {
 public static void main(String[] args) {
 int num = 9; 
 int cube = num*num*num;
 System.out.println("Cube of num:" +cube);

}
}
