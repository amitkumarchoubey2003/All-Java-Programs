class JavaString 
{ 
public static void main(String[] args) 
{  
String name = new String("Java String"); 
System.out.println(name); 
} 
}