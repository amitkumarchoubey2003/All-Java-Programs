class Main2 
{ 
public static void main(String[] args)
 { 
String first = "Java ";
 System.out.println("First String: " + first); 
String second = "Programming "; 
System.out.println("Second String: " + second); 
String add = second.concat(first); 
System.out.println("Joined String: " + add); 
} 
}