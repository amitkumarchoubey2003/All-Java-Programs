class Main4 
{ 
public static void main(String[] args) 
{  
String name = new String("Java String"); 
System.out.println(name); 
} 
}